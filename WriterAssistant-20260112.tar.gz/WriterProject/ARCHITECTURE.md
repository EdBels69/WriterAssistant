# WriterAssistant Architecture

## Overview

WriterAssistant - AI-платформа для писателей с локальным хранением данных и интеграцией GLM-4.7. Архитектура разделена на два основных компонента: Frontend (веб-приложение) и Backend (API сервер).

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (Web)                        │
│  React + Vite + Tailwind CSS                                │
│  - Dashboard                                                 │
│  - Project Management                                       │
│  - Chat Interface                                           │
│  - Statistics & Analytics                                   │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/WebSocket
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                      Backend (Node.js)                       │
│  Express.js + SQLite + WebSocket                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   Projects   │  │     Chat      │  │  Statistics  │    │
│  │  Controller  │  │  Controller   │  │  Controller  │    │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘    │
│         │                 │                  │            │
│  ┌──────▼───────┐  ┌──────▼───────┐  ┌──────▼───────┐    │
│  │   Database   │  │  GLM Service │  │ WebSocket    │    │
│  │   (SQLite)   │  │   (GLM-4.7)  │  │   Server     │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────┘
                     │
                     ▼
           ┌─────────────────┐
           │   GLM-4.7 API   │
           │   (Zhipu AI)    │
           └─────────────────┘
```

## Backend Architecture

### 1. Core Components

#### Database Layer (`src/database/`)
- **Database.js**: Менеджер SQLite базы данных
- **Таблицы**:
  - `users` - Пользователи
  - `projects` - Писательские проекты
  - `chapters` - Главы проектов
  - `scenes` - Сцены внутри глав
  - `characters` - Персонажи
  - `writing_sessions` - Сессии письма
  - `goals` - Цели и задачи
  - `chat_history` - История чата
  - `ai_requests` - Запросы к ИИ
  - `exports` - Экспортированные файлы

#### Service Layer (`src/services/`)
- **GLMService.js**: Интеграция с GLM-4.7 API
  - `generateCompletion()` - Базовый метод генерации
  - `generateIdeas()` - Генерация идей для сюжетов
  - `expandText()` - Расширение текста
  - `editStyle()` - Изменение стиля
  - `generateCharacter()` - Создание персонажа
  - `generatePlotOutline()` - Создание плана сюжета
  - `generateDialogue()` - Генерация диалогов
  - `improveWriting()` - Улучшение текста
  - `generateDescription()` - Создание описаний
  - `analyzeText()` - Анализ текста
  - `brainstorm()` - Мозговой штурм

#### Controller Layer (`src/controllers/`)
- **ProjectController.js**: Управление проектами
- **ChatController.js**: Чат с ИИ-ассистентом
- **StatisticsController.js**: Статистика и аналитика

#### WebSocket Layer (`src/websocket/`)
- **WebSocketServer.js**: Реальное время для коллаборации

### 2. API Endpoints

#### Projects (`/api/projects`)
- `GET /` - Получить все проекты пользователя
- `GET /:id` - Получить проект с главами и персонажами
- `POST /` - Создать новый проект
- `PUT /:id` - Обновить проект
- `DELETE /:id` - Удалить проект
- `GET /:id/chapters` - Получить главы проекта
- `POST /:id/chapters` - Создать главу
- `GET /:id/characters` - Получить персонажей
- `POST /:id/characters` - Создать персонажа
- `POST /:id/ideas` - Сгенерировать идеи (ИИ)
- `POST /:id/outline` - Создать план сюжета (ИИ)
- `POST /:id/expand` - Расширить текст (ИИ)

#### Chat (`/api/chat`)
- `POST /message` - Отправить сообщение ИИ
- `GET /history/:sessionId` - Получить историю чата
- `POST /clear/:sessionId` - Очистить историю

#### Statistics (`/api/statistics`)
- `GET /overview/:userId` - Обзор статистики
- `GET /productivity/:userId` - Данные продуктивности
- `GET /sessions/:userId` - Сессии письма
- `GET /goals/:userId` - Цели пользователя
- `POST /goals` - Создать цель
- `PUT /goals/:id` - Обновить цель
- `DELETE /goals/:id` - Удалить цель

## Frontend Architecture

### 1. Core Components

#### Dashboard
- Статистика (проекты, слова, сессии, продуктивность)
- Ключевые возможности
- Быстрые действия

#### Project Management
- Список проектов с прогрессом
- Создание/редактирование проектов
- Управление главами
- Управление персонажами

#### AI Assistant (Chat)
- Интерактивный чат с GLM-4.7
- Режимы: Creative, Editor, Analyst
- История сообщений
- WebSocket для реального времени

#### Statistics
- Графики продуктивности
- Метрики по проектам
- История сессий
- Управление целями

### 2. Technology Stack
- React 18
- Vite (build tool)
- Tailwind CSS
- Lucide React (icons)
- Axios (HTTP client)
- WebSocket API

## Gatsbi.AI Feature Comparison

### ✅ Implemented Features
1. **Проектное управление**
   - Создание проектов с жанрами и описаниями
   - Структура глав и сцен
   - База персонажей

2. **ИИ-помощник (GLM-4.7)**
   - Генерация идей для сюжетов
   - Создание планов глав
   - Расширение текста
   - Генерация диалогов
   - Создание персонажей
   - Стилистические правки
   - Анализ текста

3. **Статистика и аналитика**
   - Счётчик слов
   - Отслеживание сессий
   - Графики продуктивности
   - Цели и задачи

4. **Интерактивный чат**
   - Несколько режимов (Creative, Editor, Analyst)
   - История сообщений
   - Контекстное общение

5. **Локальное хранение**
   - SQLite база данных
   - Полный контроль над данными
   - Быстрая работа офлайн

### 🔄 Planned Features
1. **Экспорт**
   - PDF, DOCX, TXT
   - Форматирование
   - Настройки экспорта

2. **Коллаборация**
   - Совместное редактирование
   - Комментарии
   - Версии документов

3. **Расширенная аналитика**
   - Тренды продуктивности
   - Сравнение периодов
   - Рекомендации

4. **ИИ-функции**
   - Автодополнение текста
   - Предложения сцен
   - Анализ персонажей

## Data Flow

### 1. Creating a Project
```
Frontend → POST /api/projects
  → ProjectController.createProject()
  → Database.createProject()
  → Returns project data
  → Frontend updates UI
```

### 2. AI Chat
```
Frontend → POST /api/chat/message
  → ChatController.sendMessage()
  → GLMService.generateCompletion()
  → GLM-4.7 API
  → Returns AI response
  → Database.saveChatMessage()
  → WebSocket broadcast
  → Frontend updates chat
```

### 3. Statistics
```
Frontend → GET /api/statistics/overview/:userId
  → StatisticsController.getOverview()
  → Database queries
  → Returns aggregated data
  → Frontend renders charts
```

## Security Considerations

1. **API Keys**: Хранение в переменных окружения (.env)
2. **User Isolation**: Все данные разделены по userId
3. **Input Validation**: Joi для валидации запросов
4. **Rate Limiting**: Планируется для API endpoints
5. **CORS**: Настроено для production доменов

## Performance Optimization

1. **SQLite WAL Mode**: Быстрая запись данных
2. **Database Indexes**: Оптимизированные запросы
3. **WebSocket**: Реальное время без polling
4. **Caching**: Кэширование ИИ-ответов
5. **Connection Pooling**: Для production

## Deployment

### Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your GLM API key
npm run dev
```

### Frontend
```bash
cd web-demo
npm install
npm run dev
```

## Environment Variables

### Backend (.env)
```
PORT=5000
GLM_API_KEY=your_glm_api_key_here
NODE_ENV=development
```

## Future Enhancements

1. **Authentication**: JWT токены
2. **Cloud Sync**: Опциональная синхронизация
3. **Mobile App**: React Native приложение
4. **Plugins**: Расширяемость через API
5. **Multi-language**: Поддержка других языков ИИ

## GLM-4.7 Integration Details

### API Configuration
- Base URL: `https://open.bigmodel.cn/api/paas/v4`
- Model: `glm-4`
- Temperature: 0.5-0.9 (зависит от типа запроса)
- Max Tokens: 2000 (по умолчанию)

### Request Types
1. **Creative**: high temperature (0.8-0.9)
2. **Editor**: medium temperature (0.5-0.7)
3. **Analytics**: low temperature (0.6)

### Token Management
- Отслеживание использования токенов
- Лимиты для предотвращения превышения квоты
- Кэширование повторных запросов

## Conclusion

Эта архитектура обеспечивает масштабируемую, быструю и безопасную платформу для писателей с интеграцией GLM-4.7. Модульная структура позволяет легко расширять функционал и адаптировать систему под новые требования.