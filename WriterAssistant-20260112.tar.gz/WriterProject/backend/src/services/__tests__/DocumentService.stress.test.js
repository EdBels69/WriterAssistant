import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import DocumentService from '../DocumentService'

describe('DocumentService Stress Tests - File Upload', () => {
  let documentService
  let mockDatabase
  let mockTextChunkingService

  beforeEach(() => {
    vi.clearAllMocks()
    vi.useFakeTimers()

    mockDatabase = {
      run: vi.fn(),
      all: vi.fn(),
      get: vi.fn()
    }

    mockTextChunkingService = {
      chunkText: vi.fn()
    }

    documentService = new DocumentService(mockDatabase, mockTextChunkingService)
  })

  afterEach(() => {
    vi.restoreAllMocks()
    vi.useRealTimers()
  })

  describe('File Size Validation', () => {
    it('должен отклонять файл > 50MB', async () => {
      const mockFile = {
        originalname: 'large.txt',
        mimetype: 'text/plain',
        size: 52 * 1024 * 1024
      }

      await expect(
        documentService.uploadDocument(mockFile, 'user-1', 'project-1')
      ).rejects.toMatchObject({
        code: 'FILE_TOO_LARGE',
        message: expect.stringContaining('превышает лимит 50MB')
      })
    })

    it('должен принимать файл 50MB', async () => {
      const mockFile = {
        originalname: 'exact50.txt',
        mimetype: 'text/plain',
        size: 50 * 1024 * 1024
      }

      mockDatabase.run.mockResolvedValue({ lastID: 1 })

      const result = await documentService.uploadDocument(mockFile, 'user-1', 'project-1')

      expect(result).toBeDefined()
    })

    it('должен отклонять файл < 1KB', async () => {
      const mockFile = {
        originalname: 'tiny.txt',
        mimetype: 'text/plain',
        size: 512
      }

      await expect(
        documentService.uploadDocument(mockFile, 'user-1', 'project-1')
      ).rejects.toMatchObject({
        code: 'FILE_TOO_SMALL',
        message: expect.stringContaining('слишком мал')
      })
    })
  })

  describe('Total Size Validation', () => {
    it('должен отклонять загрузку если общий размер > 100MB', async () => {
      mockDatabase.all.mockResolvedValue([
        { size: 60 * 1024 * 1024 },
        { size: 35 * 1024 * 1024 }
      ])

      const mockFile = {
        originalname: 'new.txt',
        mimetype: 'text/plain',
        size: 10 * 1024 * 1024
      }

      await expect(
        documentService.uploadDocument(mockFile, 'user-1', 'project-1')
      ).rejects.toMatchObject({
        code: 'TOTAL_SIZE_EXCEEDED',
        message: expect.stringContaining('превышает лимит 100MB')
      })
    })

    it('должен принимать загрузку если общий размер = 100MB', async () => {
      mockDatabase.all.mockResolvedValue([
        { size: 50 * 1024 * 1024 }
      ])

      const mockFile = {
        originalname: 'new.txt',
        mimetype: 'text/plain',
        size: 50 * 1024 * 1024
      }

      mockDatabase.run.mockResolvedValue({ lastID: 1 })

      const result = await documentService.uploadDocument(mockFile, 'user-1', 'project-1')

      expect(result).toBeDefined()
    })
  })

  describe('MIME Type Validation', () => {
    it('должен отклонять .exe файлы', async () => {
      const mockFile = {
        originalname: 'malware.exe',
        mimetype: 'application/x-msdownload',
        size: 1024 * 1024
      }

      await expect(
        documentService.uploadDocument(mockFile, 'user-1', 'project-1')
      ).rejects.toMatchObject({
        code: 'UNSUPPORTED_MIMETYPE',
        message: expect.stringContaining('неподдерживаемый формат')
      })
    })

    it('должен принимать поддерживаемые MIME типы', async () => {
      const supportedMimeTypes = [
        'text/plain',
        'text/markdown',
        'application/json',
        'text/csv',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ]

      for (const mimeType of supportedMimeTypes) {
        const mockFile = {
          originalname: `test.${mimeType.split('/')[1]}`,
          mimetype: mimeType,
          size: 1024 * 1024
        }

        mockDatabase.run.mockResolvedValue({ lastID: 1 })

        const result = await documentService.uploadDocument(mockFile, 'user-1', 'project-1')
        expect(result).toBeDefined()
      }
    })
  })

  describe('Concurrent Uploads', () => {
    it('должен обрабатывать 10 параллельных загрузок', async () => {
      mockDatabase.all.mockResolvedValue([])
      mockDatabase.run.mockResolvedValue({ lastID: 1 })

      const uploadPromises = Array(10).fill(0).map((_, i) => {
        const mockFile = {
          originalname: `file${i}.txt`,
          mimetype: 'text/plain',
          size: 1024 * 1024
        }

        return documentService.uploadDocument(mockFile, 'user-1', 'project-1')
      })

      const results = await Promise.all(uploadPromises)

      expect(results).toHaveLength(10)
      expect(mockDatabase.run).toHaveBeenCalledTimes(10)
    })

    it('должен корректно обрабатывать ошибки при параллельных загрузках', async () => {
      mockDatabase.all.mockResolvedValue([])
      mockDatabase.run
        .mockResolvedValueOnce({ lastID: 1 })
        .mockRejectedValueOnce(new Error('Database error'))
        .mockResolvedValueOnce({ lastID: 2 })
        .mockRejectedValueOnce(new Error('Database error'))

      const uploadPromises = Array(4).fill(0).map((_, i) => {
        const mockFile = {
          originalname: `file${i}.txt`,
          mimetype: 'text/plain',
          size: 1024 * 1024
        }

        return documentService.uploadDocument(mockFile, 'user-1', 'project-1')
      })

      const results = await Promise.allSettled(uploadPromises)

      const successCount = results.filter(r => r.status === 'fulfilled').length
      const failureCount = results.filter(r => r.status === 'rejected').length

      expect(successCount).toBe(2)
      expect(failureCount).toBe(2)
    })
  })

  describe('Memory Management', () => {
    it('должен корректно обрабатывать большие файлы без утечек памяти', async () => {
      const largeFile = {
        originalname: 'large.txt',
        mimetype: 'text/plain',
        size: 45 * 1024 * 1024
      }

      mockDatabase.all.mockResolvedValue([])
      mockDatabase.run.mockResolvedValue({ lastID: 1 })

      const result = await documentService.uploadDocument(largeFile, 'user-1', 'project-1')

      expect(result).toBeDefined()
    })

    it('должен очищать временные файлы', async () => {
      const mockFile = {
        originalname: 'test.txt',
        mimetype: 'text/plain',
        size: 1024 * 1024,
        path: '/tmp/test.txt'
      }

      mockDatabase.all.mockResolvedValue([])
      mockDatabase.run.mockResolvedValue({ lastID: 1 })

      await documentService.uploadDocument(mockFile, 'user-1', 'project-1')

      expect(mockDatabase.run).toHaveBeenCalled()
    })
  })

  describe('Edge Cases', () => {
    it('должен обрабатывать пустой файл (0 bytes)', async () => {
      const emptyFile = {
        originalname: 'empty.txt',
        mimetype: 'text/plain',
        size: 0
      }

      await expect(
        documentService.uploadDocument(emptyFile, 'user-1', 'project-1')
      ).rejects.toMatchObject({
        code: 'FILE_TOO_SMALL'
      })
    })

    it('должен обрабатывать файл с размером точно 50MB', async () => {
      const exactSizeFile = {
        originalname: 'exact50.txt',
        mimetype: 'text/plain',
        size: 50 * 1024 * 1024
      }

      mockDatabase.all.mockResolvedValue([])
      mockDatabase.run.mockResolvedValue({ lastID: 1 })

      const result = await documentService.uploadDocument(exactSizeFile, 'user-1', 'project-1')

      expect(result).toBeDefined()
    })

    it('должен обрабатывать файл с размером 50MB + 1 byte', async () => {
      const overSizeFile = {
        originalname: 'over50.txt',
        mimetype: 'text/plain',
        size: 50 * 1024 * 1024 + 1
      }

      await expect(
        documentService.uploadDocument(overSizeFile, 'user-1', 'project-1')
      ).rejects.toMatchObject({
        code: 'FILE_TOO_LARGE'
      })
    })
  })

  describe('Text Chunking Integration', () => {
    it('должен разбивать большой текст на чанки', async () => {
      const mockFile = {
        originalname: 'large.txt',
        mimetype: 'text/plain',
        size: 10 * 1024 * 1024,
        buffer: Buffer.from('x'.repeat(10 * 1024 * 1024))
      }

      mockDatabase.all.mockResolvedValue([])
      mockDatabase.run.mockResolvedValue({ lastID: 1 })
      mockTextChunkingService.chunkText.mockResolvedValue([
        { id: 1, content: 'chunk 1', metadata: { start: 0, end: 5000 } },
        { id: 2, content: 'chunk 2', metadata: { start: 5000, end: 10000 } }
      ])

      const result = await documentService.uploadDocument(mockFile, 'user-1', 'project-1')

      expect(mockTextChunkingService.chunkText).toHaveBeenCalled()
    })
  })
})
