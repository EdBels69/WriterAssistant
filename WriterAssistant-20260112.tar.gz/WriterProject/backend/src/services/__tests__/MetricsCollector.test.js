import MetricsCollector from '../MetricsCollector.js'

describe('MetricsCollector', () => {
  let collector

  beforeEach(() => {
    collector = new MetricsCollector()
  })

  afterEach(() => {
    collector.clear()
  })

  describe('recordMetric', () => {
    test('should record metric with all fields', () => {
      collector.recordMetric('creative', 'generateIdeas', {
        responseTime: 1500,
        success: true,
        outputLength: 1000,
        qualityScore: 85,
        error: null
      })

      const metrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      expect(metrics.count).toBe(1)
      expect(metrics.totalResponseTime).toBe(1500)
    })

    test('should record multiple metrics for same instrument', () => {
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 1000, success: true, outputLength: 500, qualityScore: 80, error: null })
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 2000, success: true, outputLength: 800, qualityScore: 90, error: null })

      const metrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      expect(metrics.count).toBe(2)
      expect(metrics.totalResponseTime).toBe(3000)
    })

    test('should handle different categories separately', () => {
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 1000, success: true, outputLength: 500, qualityScore: 80, error: null })
      collector.recordMetric('research', 'hypothesis', { responseTime: 1500, success: true, outputLength: 600, qualityScore: 85, error: null })

      const creativeMetrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      const researchMetrics = collector.getAggregatedMetrics('research', 'hypothesis')

      expect(creativeMetrics.count).toBe(1)
      expect(researchMetrics.count).toBe(1)
    })
  })

  describe('getAggregatedMetrics', () => {
    beforeEach(() => {
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 1000, success: true, outputLength: 500, qualityScore: 80, error: null })
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 2000, success: true, outputLength: 800, qualityScore: 90, error: null })
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 1500, success: false, outputLength: 0, qualityScore: 0, error: 'API error' })
    })

    test('should calculate average response time', () => {
      const metrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      expect(metrics.avgResponseTime).toBe(1500)
    })

    test('should calculate success rate', () => {
      const metrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      expect(metrics.successRate).toBe(2 / 3)
    })

    test('should calculate average quality score', () => {
      const metrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      expect(metrics.avgQualityScore).toBe((80 + 90 + 0) / 3)
    })

    test('should return zero for non-existent instrument', () => {
      const metrics = collector.getAggregatedMetrics('nonexistent', 'instrument')
      expect(metrics.count).toBe(0)
      expect(metrics.avgResponseTime).toBe(0)
    })
  })

  describe('percentile', () => {
    test('should calculate 50th percentile (median)', () => {
      const arr = [1, 2, 3, 4, 5]
      const result = collector.percentile(arr, 50)
      expect(result).toBe(3)
    })

    test('should calculate 90th percentile', () => {
      const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
      const result = collector.percentile(arr, 90)
      expect(result).toBe(9)
    })

    test('should handle empty array', () => {
      const result = collector.percentile([], 50)
      expect(result).toBe(0)
    })

    test('should handle single element array', () => {
      const result = collector.percentile([5], 50)
      expect(result).toBe(5)
    })
  })

  describe('getReport', () => {
    beforeEach(() => {
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 1000, success: true, outputLength: 500, qualityScore: 80, error: null })
      collector.recordMetric('research', 'hypothesis', { responseTime: 1500, success: true, outputLength: 600, qualityScore: 85, error: null })
    })

    test('should generate report for all categories', () => {
      const report = collector.getReport()
      
      expect(report).toHaveProperty('creative')
      expect(report).toHaveProperty('research')
      expect(report.creative).toHaveProperty('generateIdeas')
      expect(report.research).toHaveProperty('hypothesis')
    })

    test('should include summary statistics', () => {
      const report = collector.getReport()
      
      expect(report).toHaveProperty('totalRequests')
      expect(report).toHaveProperty('totalErrors')
      expect(report).toHaveProperty('avgResponseTime')
      expect(report.totalRequests).toBe(2)
    })
  })

  describe('clear', () => {
    test('should clear all metrics', () => {
      collector.recordMetric('creative', 'generateIdeas', { responseTime: 1000, success: true, outputLength: 500, qualityScore: 80, error: null })
      
      collector.clear()
      
      const metrics = collector.getAggregatedMetrics('creative', 'generateIdeas')
      expect(metrics.count).toBe(0)
    })
  })
})
