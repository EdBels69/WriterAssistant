import { useNavigate } from 'react-router-dom'
import { BookOpen, MessageSquare, Settings } from 'lucide-react'

export default function Header({ isConnected, setIsChatOpen, setShowSettings }) {
  const navigate = useNavigate()

  const handleChatClick = () => {
    navigate('/chat')
  }

  return (
    <header className="bg-dark-card/80 backdrop-blur-lg border-b border-dark-border sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-primary p-2.5 rounded-xl shadow-glow" aria-hidden="true">
              <BookOpen className="text-white" size={24} />
            </div>
            <h1 className="text-xl font-bold font-display tracking-tight">WriterAssistant</h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-dark-card rounded-lg border border-dark-border">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-accent-emerald shadow-glow' : 'bg-red-500'}`}></div>
              <span className="text-xs text-dark-muted">
                {isConnected ? 'Подключено' : 'Отключено'}
              </span>
            </div>
            <button
              type="button"
              onClick={handleChatClick}
              className="flex items-center gap-2 bg-gradient-primary text-white px-4 py-2.5 rounded-xl hover:shadow-glow-strong transition-all transform hover:-translate-y-0.5"
              aria-label="Открыть ИИ-помощника"
            >
              <MessageSquare size={18} aria-hidden="true" />
              ИИ-помощник
            </button>
            <button
              type="button"
              onClick={() => setShowSettings(true)}
              className="p-2 text-dark-muted hover:text-white hover:bg-dark-card rounded-lg transition-colors"
              aria-label="Настройки"
            >
              <Settings size={24} aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
