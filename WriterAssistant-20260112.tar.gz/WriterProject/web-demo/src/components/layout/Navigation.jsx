import { useNavigate, useLocation } from 'react-router-dom'
import { ChevronDown, ChevronRight, BookOpen, BarChart3, Activity, Edit3, Code, Brain, Sparkles, Target, MessageSquare, Network, MessageSquare as ChatIcon } from 'lucide-react'

const navItems = [
  { id: 'dashboard', label: 'Обзор', icon: Activity, path: '/' },
  { id: 'projects', label: 'Проекты', icon: BookOpen, path: '/projects' },
  { id: 'tools', label: 'Инструменты', icon: Sparkles, path: '/tools' },
  { id: 'chat', label: 'Чат', icon: ChatIcon, path: '/chat' }
]

const dropdownItems = {
  analysis: {
    label: 'Инструменты анализа',
    items: [
      { id: 'data-analysis', label: 'Анализ данных', icon: Sparkles },
      { id: 'literature-review', label: 'Обзор литературы', icon: BookOpen },
      { id: 'statistical-analysis', label: 'Статистический анализ', icon: BarChart3 },
      { id: 'style-formatting', label: 'Стиль и форматирование', icon: Edit3 }
    ]
  },
  tools: {
    label: 'Инструменты',
    items: [
      { id: 'code-tools', label: 'Код', icon: Code },
      { id: 'multi-agent', label: 'Мультиагентный ИИ', icon: Brain }
    ]
  }
}

export default function Navigation({ activeTab, activeDropdown, activeToolScreen, setActiveTab, setActiveDropdown, setActiveToolScreen }) {
  const navigate = useNavigate()
  const location = useLocation()

  const handleNavClick = (path) => {
    navigate(path)
    setActiveTab(path.replace('/', '') || 'dashboard')
    setActiveToolScreen(null)
    setActiveDropdown(null)
  }

  return (
    <div className="flex gap-2 mt-4" role="tablist" aria-label="Основная навигация">
      {navItems.map((item) => (
        <button
          key={item.id}
          type="button"
          role="tab"
          aria-selected={location.pathname === item.path}
          aria-controls={`${item.id}-panel`}
          onClick={() => handleNavClick(item.path)}
          className={`px-4 py-2.5 rounded-xl font-medium transition-all flex items-center gap-2 ${
            location.pathname === item.path
              ? 'bg-gradient-primary text-white shadow-glow'
              : 'text-dark-muted hover:bg-dark-card hover:text-white'
          }`}
        >
          <item.icon size={18} aria-hidden="true" />
          {item.label}
        </button>
      ))}

      {Object.entries(dropdownItems).map(([key, dropdown]) => (
        <div key={key} className="relative">
          <button
            type="button"
            onClick={() => {
              setActiveDropdown(activeDropdown === key ? null : key)
              if (activeDropdown !== key) {
                navigate('/tools')
              }
            }}
            aria-expanded={activeDropdown === key}
            aria-haspopup="true"
            className={`px-4 py-2.5 rounded-xl font-medium transition-all flex items-center gap-2 ${
              activeDropdown === key || activeToolScreen
                ? 'bg-gradient-primary text-white shadow-glow'
                : 'text-dark-muted hover:bg-dark-card hover:text-white'
            }`}
          >
            {dropdown.label}
            {activeDropdown === key ? <ChevronDown size={16} aria-hidden="true" /> : <ChevronRight size={16} aria-hidden="true" />}
          </button>

          {activeDropdown === key && (
            <div className="absolute top-full left-0 mt-2 w-56 bg-dark-card border border-dark-border rounded-xl shadow-2xl z-50" role="menu">
              {dropdown.items.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setActiveToolScreen(item.id)
                    setActiveDropdown(null)
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-dark-border transition-colors first:rounded-t-xl last:rounded-b-xl"
                >
                  <item.icon size={18} className="text-primary-500" aria-hidden="true" />
                  <span className="text-dark-text">{item.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
