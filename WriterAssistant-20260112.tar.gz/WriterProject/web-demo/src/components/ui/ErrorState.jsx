export default function ErrorState({ error }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-bg">
      <div className="text-center">
        <div className="bg-red-900/20 border border-red-500/30 text-red-400 p-4 rounded-xl mb-4 backdrop-blur-sm" role="alert" aria-live="assertive">
          {error}
        </div>
        <p className="text-dark-muted text-sm">Убедитесь, что backend сервер запущен на порту 5001</p>
      </div>
    </div>
  )
}
