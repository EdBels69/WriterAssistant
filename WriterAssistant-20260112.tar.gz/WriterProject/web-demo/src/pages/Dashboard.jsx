import { memo } from 'react'
import { FileText, BookOpen, BarChart3, Edit3 } from 'lucide-react'

function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="card-elevated p-8 bg-dark-card/50 backdrop-blur-xl border border-dark-border rounded-2xl">
        <h2 className="section-header mb-6 text-white font-display">Добро пожаловать в ScientificWriter AI</h2>

        <p className="text-dark-muted mb-6">
          Интеллектуальный помощник для научных исследований. Используйте вкладку «Инструменты анализа» для доступа к всем функциям.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 bg-accent-cyan/10 rounded-xl border border-accent-cyan/20 hover:border-accent-cyan/40 transition-colors group">
            <div className="p-3 rounded-lg bg-accent-cyan/20 w-fit mb-4 group-hover:shadow-glow transition-shadow">
              <FileText size={24} className="text-accent-cyan" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-white mb-2">Анализ данных</h3>
            <p className="text-sm text-dark-muted">Структурирование идей, извлечение ссылок, генерация гипотез</p>
          </div>

          <div className="p-6 bg-accent-purple/10 rounded-xl border border-accent-purple/20 hover:border-accent-purple/40 transition-colors group">
            <div className="p-3 rounded-lg bg-accent-purple/20 w-fit mb-4 group-hover:shadow-glow transition-shadow">
              <BookOpen size={24} className="text-accent-purple" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-white mb-2">Обзор литературы</h3>
            <p className="text-sm text-dark-muted">Нарративный, систематический обзор, мета-анализ</p>
          </div>

          <div className="p-6 bg-accent-emerald/10 rounded-xl border border-accent-emerald/20 hover:border-accent-emerald/40 transition-colors group">
            <div className="p-3 rounded-lg bg-accent-emerald/20 w-fit mb-4 group-hover:shadow-glow transition-shadow">
              <BarChart3 size={24} className="text-accent-emerald" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-white mb-2">Статистический анализ</h3>
            <p className="text-sm text-dark-muted">Интерпретация результатов, анализ данных</p>
          </div>

          <div className="p-6 bg-accent-pink/10 rounded-xl border border-accent-pink/20 hover:border-accent-pink/40 transition-colors group">
            <div className="p-3 rounded-lg bg-accent-pink/20 w-fit mb-4 group-hover:shadow-glow transition-shadow">
              <Edit3 size={24} className="text-accent-pink" aria-hidden="true" />
            </div>
            <h3 className="font-bold text-white mb-2">Стиль и форматирование</h3>
            <p className="text-sm text-dark-muted">Академический стиль, редактирование текстов</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default memo(Dashboard)
