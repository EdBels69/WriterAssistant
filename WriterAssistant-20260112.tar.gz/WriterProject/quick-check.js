#!/usr/bin/env node

/**
 * Writer Assistant - Quick Prototype Check
 * Verifies critical components without requiring server restart
 */

const fs = require('fs');
const path = require('path');

const COLORS = {
  GREEN: '\x1b[32m',
  RED: '\x1b[31m',
  YELLOW: '\x1b[33m',
  NC: '\x1b[0m'
};

function log(message, color = COLORS.NC) {
  console.log(`${color}${message}${COLORS.NC}`);
}

function checkFile(filePath, description) {
  const fullPath = path.join(__dirname, filePath);
  if (fs.existsSync(fullPath)) {
    log(`✅ ${description}`, COLORS.GREEN);
    return true;
  } else {
    log(`❌ ${description} - NOT FOUND`, COLORS.RED);
    return false;
  }
}

function checkFileContent(filePath, patterns, description) {
  const fullPath = path.join(__dirname, filePath);
  if (!fs.existsSync(fullPath)) {
    log(`❌ ${description} - FILE NOT FOUND`, COLORS.RED);
    return false;
  }

  const content = fs.readFileSync(fullPath, 'utf8');
  const missing = [];

  patterns.forEach(pattern => {
    if (!content.includes(pattern)) {
      missing.push(pattern);
    }
  });

  if (missing.length === 0) {
    log(`✅ ${description}`, COLORS.GREEN);
    return true;
  } else {
    log(`⚠️  ${description} - Missing: ${missing.join(', ')}`, COLORS.YELLOW);
    return false;
  }
}

console.log('=== WRITER ASSISTANT - PROTOTYPE QUICK CHECK ===\n');

let passed = 0;
let total = 0;

// CHECK 1: API Keys
total++;
if (checkFileContent('backend/.env', [
  'GLM_API_KEY=',
  'GLM_SECONDARY_API_KEY=',
  'OPENROUTER_API_KEY='
], 'API Keys in .env')) {
  passed++;
}

// CHECK 2: Backend Configuration
total++;
if (checkFileContent('backend/src/index.js', [
  'PORT',
  'app.listen',
  'metricsRouter',
  'selfTestRouter'
], 'Backend server configuration')) {
  passed++;
}

// CHECK 3: Frontend Configuration
total++;
if (checkFileContent('web-demo/vite.config.js', [
  'port',
  'server'
], 'Frontend Vite configuration')) {
  passed++;
}

// CHECK 4: Error Handling
total++;
if (checkFile('backend/src/middleware/errorHandler.js', 'Error handler middleware')) {
  passed++;
}

// CHECK 5: Validation Middleware
total++;
if (checkFile('backend/src/middleware/validation.js', 'Validation middleware')) {
  passed++;
}

// CHECK 6: SmartRouter
total++;
if (checkFileContent('backend/src/services/SmartRouter.js', [
  'class SmartRouter',
  'routeRequest',
  'getCacheKey',
  'simpleHash'
], 'SmartRouter with cache')) {
  passed++;
}

// CHECK 7: GLMService
total++;
if (checkFileContent('backend/src/services/GLMService.js', [
  'class GLMService',
  'httpAgent',
  'pendingRequests',
  'getRequestKey'
], 'GLMService with connection pooling')) {
  passed++;
}

// CHECK 8: AIController
total++;
if (checkFileContent('backend/src/controllers/AIController.js', [
  'class AIController',
  'outputValidator',
  'metricsCollector',
  'prismaFlowGenerator'
], 'AIController with lazy loading')) {
  passed++;
}

// CHECK 9: OutputValidator
total++;
if (checkFile('backend/src/services/OutputValidator.js', 'OutputValidator service')) {
  passed++;
}

// CHECK 10: Humanizer
total++;
if (checkFile('backend/src/services/Humanizer.js', 'Humanizer service')) {
  passed++;
}

// CHECK 11: PrismaFlowGenerator
total++;
if (checkFile('backend/src/services/PrismaFlowGenerator.js', 'PrismaFlowGenerator service')) {
  passed++;
}

// CHECK 12: ForestPlotGenerator
total++;
if (checkFile('backend/src/services/ForestPlotGenerator.js', 'ForestPlotGenerator service')) {
  passed++;
}

// CHECK 13: Frontend Pages
const pages = ['DashboardPage', 'ChatPage', 'ToolsPage', 'ProjectsPage', 'AnalysisTools'];
total++;
let allPagesExist = true;
pages.forEach(page => {
  const pagePath = `web-demo/src/pages/${page}.jsx`;
  if (!fs.existsSync(path.join(__dirname, pagePath))) {
    allPagesExist = false;
  }
});
if (allPagesExist) {
  log(`✅ Frontend pages (${pages.length} pages)`, COLORS.GREEN);
  passed++;
} else {
  log(`❌ Frontend pages - Some pages missing`, COLORS.RED);
}

// CHECK 14: Frontend Components
total++;
if (checkFile('web-demo/src/components/Chat.jsx', 'Chat component')) {
  passed++;
}

// CHECK 15: React.memo
total++;
if (checkFileContent('web-demo/src/pages/ChatPage.jsx', [
  'import { memo }',
  'export default memo('
], 'React.memo optimization')) {
  passed++;
}

// CHECK 16: Debounce Utility
total++;
if (checkFile('web-demo/src/utils/debounce.js', 'Debounce utility')) {
  passed++;
}

// CHECK 17: Test Files
const testFiles = [
  'backend/src/services/__tests__/SmartRouter.test.js',
  'backend/src/middleware/__tests__/validation.test.js',
  'backend/src/services/__tests__/MetricsCollector.test.js',
  'backend/src/services/__tests__/OutputValidator.test.js',
  'backend/src/services/__tests__/Humanizer.test.js'
];
total++;
let allTestsExist = true;
testFiles.forEach(testFile => {
  if (!fs.existsSync(path.join(__dirname, testFile))) {
    allTestsExist = false;
  }
});
if (allTestsExist) {
  log(`✅ Test files (${testFiles.length} test files)`, COLORS.GREEN);
  passed++;
} else {
  log(`❌ Test files - Some files missing`, COLORS.RED);
}

// CHECK 18: Scripts
const scripts = ['start-all.sh', 'run-tests.sh', 'check-proto.sh'];
total++;
let allScriptsExist = true;
scripts.forEach(script => {
  if (!fs.existsSync(path.join(__dirname, script))) {
    allScriptsExist = false;
  }
});
if (allScriptsExist) {
  log(`✅ Launch scripts (${scripts.length} scripts)`, COLORS.GREEN);
  passed++;
} else {
  log(`❌ Launch scripts - Some scripts missing`, COLORS.RED);
}

// CHECK 19: Documentation
total++;
if (checkFile('../README.md', 'README documentation') &&
    checkFile('../report.md', 'Implementation report') &&
    checkFile('../PROJECT_STATUS.md', 'Project status')) {
  passed++;
}

// CHECK 20: Manual Test Script
total++;
if (checkFile('backend/manual-test.js', 'Manual test script')) {
  passed++;
}

// SUMMARY
console.log('\n=== SUMMARY ===');
console.log(`Passed: ${passed}/${total}`);
const percentage = Math.round((passed / total) * 100);
console.log(`Readiness: ${percentage}%`);

if (percentage >= 90) {
  log('\n🚀 PROTOTYPE READY TO LAUNCH!', COLORS.GREEN);
  console.log('\nNext steps:');
  console.log('1. cd WriterProject/backend && npm start');
  console.log('2. cd WriterProject/web-demo && npm run dev');
  console.log('3. Open http://localhost:5173');
} else if (percentage >= 70) {
  log('\n⚠️  PROTOTYPE ALMOST READY - Minor issues found', COLORS.YELLOW);
} else {
  log('\n❌ PROTOTYPE NOT READY - Critical issues found', COLORS.RED);
}

console.log('\nFor full verification, run: ./check-proto.sh');
