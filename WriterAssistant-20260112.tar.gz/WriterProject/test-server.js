import express from 'express'
import cors from 'cors'

const app = express()
const PORT = 5173

app.use(cors())
app.use(express.json())

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Test Server</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          background: #0a0a0f; 
          color: #e5e5e5; 
          padding: 50px;
          text-align: center;
        }
        h1 { color: #7c3aed; }
        .status { 
          background: #1a1a2e; 
          padding: 20px; 
          border-radius: 10px; 
          margin: 20px 0;
        }
        .success { color: #10b981; }
      </style>
    </head>
    <body>
      <h1>✓ Writer Assistant Server</h1>
      <div class="status">
        <p class="success">Frontend работает на порту ${PORT}</p>
        <p>Backend должен работать на порту 5001</p>
      </div>
    </body>
    </html>
  `)
})

app.listen(PORT, () => {
  console.log(`Test server running on http://localhost:${PORT}`)
})

export default app
