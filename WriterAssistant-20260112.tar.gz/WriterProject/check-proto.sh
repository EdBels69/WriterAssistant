#!/bin/bash

# Writer Assistant - Prototype Verification Script
# Based on review.md v7.0 checklist

set -e

echo "=== WRITER ASSISTANT - PROTOTYPE VERIFICATION ==="
echo "Review.md v7.0 Checklist"
echo ""

BACKEND_DIR="/Users/eduardbelskih/Проекты Github/WriterAssistant/WriterProject/backend"
FRONTEND_DIR="/Users/eduardbelskih/Проекты Github/WriterAssistant/WriterProject/web-demo"
PORT=5001

# COLORS
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# CHECK 1: API Keys
echo "1. Checking API keys in .env..."
if [ -f "$BACKEND_DIR/.env" ]; then
    if grep -q "GLM_API_KEY=" "$BACKEND_DIR/.env" && \
       grep -q "GLM_SECONDARY_API_KEY=" "$BACKEND_DIR/.env" && \
       grep -q "OPENROUTER_API_KEY=" "$BACKEND_DIR/.env"; then
        echo -e "${GREEN}✅${NC} API keys found in .env"
    else
        echo -e "${RED}❌${NC} Missing API keys in .env"
        exit 1
    fi
else
    echo -e "${RED}❌${NC} .env file not found"
    exit 1
fi

# CHECK 2: Backend dependencies
echo ""
echo "2. Checking backend dependencies..."
if [ -d "$BACKEND_DIR/node_modules" ]; then
    echo -e "${GREEN}✅${NC} Backend node_modules exists"
else
    echo -e "${YELLOW}⚠️${NC} Installing backend dependencies..."
    cd "$BACKEND_DIR" && npm install
    echo -e "${GREEN}✅${NC} Backend dependencies installed"
fi

# CHECK 3: Frontend dependencies
echo ""
echo "3. Checking frontend dependencies..."
if [ -d "$FRONTEND_DIR/node_modules" ]; then
    echo -e "${GREEN}✅${NC} Frontend node_modules exists"
else
    echo -e "${YELLOW}⚠️${NC} Installing frontend dependencies..."
    cd "$FRONTEND_DIR" && npm install
    echo -e "${GREEN}✅${NC} Frontend dependencies installed"
fi

# CHECK 4: Start backend server
echo ""
echo "4. Starting backend server on port $PORT..."
cd "$BACKEND_DIR"
npm start &
BACKEND_PID=$!
echo -e "${YELLOW}⏳${NC} Backend server starting (PID: $BACKEND_PID)"

# Wait for server to start
sleep 5

# CHECK 5: Health endpoint
echo ""
echo "5. Testing /health endpoint..."
if curl -s http://localhost:$PORT/health | grep -q "ok"; then
    echo -e "${GREEN}✅${NC} /health endpoint responding"
else
    echo -e "${RED}❌${NC} /health endpoint not responding"
    kill $BACKEND_PID 2>/dev/null || true
    exit 1
fi

# CHECK 6: Metrics endpoint
echo ""
echo "6. Testing /api/metrics/dashboard endpoint..."
if curl -s http://localhost:$PORT/api/metrics/dashboard | grep -q "success"; then
    echo -e "${GREEN}✅${NC} Metrics endpoint responding"
else
    echo -e "${YELLOW}⚠️${NC} Metrics endpoint may not be fully configured"
fi

# CHECK 7: Self-test endpoint
echo ""
echo "7. Testing self-test endpoint..."
RESPONSE=$(curl -s -X POST http://localhost:$PORT/api/self-test/run/unit \
  -H "Content-Type: application/json")
if echo "$RESPONSE" | grep -q "success"; then
    echo -e "${GREEN}✅${NC} Self-test endpoint responding"
    SUCCESS_RATE=$(echo "$RESPONSE" | grep -o '"successRate":[0-9.]*' | cut -d':' -f2)
    echo -e "   Success rate: ${SUCCESS_RATE}"
else
    echo -e "${YELLOW}⚠️${NC} Self-test endpoint response: $RESPONSE"
fi

# CHECK 8: AI generation test
echo ""
echo "8. Testing AI generation (ideas endpoint)..."
AI_RESPONSE=$(curl -s -X POST http://localhost:$PORT/api/ai/ideas \
  -H "Content-Type: application/json" \
  -d '{"genre":"sci-fi","theme":"space exploration"}')
if echo "$AI_RESPONSE" | grep -q "success"; then
    echo -e "${GREEN}✅${NC} AI generation working"
else
    echo -e "${YELLOW}⚠️${NC} AI generation response: $AI_RESPONSE"
fi

# SUMMARY
echo ""
echo "=== VERIFICATION COMPLETE ==="
echo -e "${GREEN}✅${NC} Backend server running (PID: $BACKEND_PID)"
echo -e "${GREEN}✅${NC} Backend URL: http://localhost:$PORT"
echo -e "${GREEN}✅${NC} Frontend: cd $FRONTEND_DIR && npm run dev"
echo ""
echo "To stop backend server: kill $BACKEND_PID"
echo ""
echo "Next steps:"
echo "1. Open new terminal and run: cd \"$FRONTEND_DIR\" && npm run dev"
echo "2. Open http://localhost:5173 in browser"
echo "3. Test chat functionality"
echo "4. Test AI generation tools"
