import SwiftUI

struct LogsView: View {
    @EnvironmentObject var logManager: LogManager
    @Environment(\.dismiss) var dismiss
    @Binding var isPresented: Bool
    
    @State private var selectedLogLevel: LogEntry.Level = .info
    @State private var searchText = ""
    @State private var isAutoScrolling = true
    @State private var showingExportAlert = false
    @State private var exportContent = ""
    
    private var filteredLogs: [LogEntry] {
        Logger.shared.logs
            .filter { log in
                let matchesLevel = selectedLogLevel == .debug || log.level == selectedLogLevel.rawValue
                let matchesSearch = searchText.isEmpty || log.message.localizedCaseInsensitiveContains(searchText)
                return matchesLevel && matchesSearch
            }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            header
            
            Divider()
                .background(NSAppearance.current.isDark ? Color.RooCodeDark.border : Color.RooCode.border)
            
            toolbar
            
            Divider()
                .background(NSAppearance.current.isDark ? Color.RooCodeDark.border : Color.RooCode.border)
            
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 4) {
                        if filteredLogs.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "doc.text.magnifyingglass")
                                    .font(.system(size: 48))
                                    .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary)
                                
                                Text("Логи не найдены")
                                    .font(.RooCode.body)
                                    .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary)
                            }
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .padding(40)
                        } else {
                            ForEach(Array(filteredLogs.enumerated()), id: \.element.id) { index, log in
                                LogRow(log: log)
                                    .id(log.id)
                                    .onAppear {
                                        if isAutoScrolling && index == filteredLogs.count - 1 {
                                            proxy.scrollTo(log.id, anchor: .bottom)
                                        }
                                    }
                            }
                        }
                    }
                    .padding(16)
                }
            }
            
            Divider()
                .background(NSAppearance.current.isDark ? Color.RooCodeDark.border : Color.RooCode.border)
            
            footer
        }
        .frame(width: 900, height: 600)
        .themeSurface()
        .alert("Экспорт логов", isPresented: $showingExportAlert) {
            Button("Копировать", action: copyLogs)
            Button("Сохранить", action: saveLogs)
            Button("Отмена", role: .cancel) { }
        } message: {
            Text("Выберите действие для экспорта логов")
        }
    }
    
    private var header: some View {
        HStack {
            Text("Логи приложения")
                .font(.RooCode.title3)
                .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.text : Color.RooCode.text)
            
            Spacer()
            
            Button(action: { isPresented = false }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 20))
                    .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 20)
    }
    
    private var toolbar: some View {
        HStack(spacing: 12) {
            Picker("Уровень", selection: $selectedLogLevel) {
                Text("Все").tag(LogEntry.Level.debug)
                ForEach(LogEntry.Level.allCases, id: \.self) { level in
                    Text(level.displayName).tag(level)
                }
            }
            .pickerStyle(.segmented)
            .frame(width: 350)
            
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary)
                
                TextField("Поиск", text: $searchText)
                    .textFieldStyle(.plain)
                    .font(.RooCode.body)
                    .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.text : Color.RooCode.text)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(NSAppearance.current.isDark ? Color.RooCodeDark.border : Color.RooCode.border)
            .cornerRadius(6)
            
            Spacer()
            
            Button(action: { isAutoScrolling.toggle() }) {
                Image(systemName: isAutoScrolling ? "arrow.down.circle.fill" : "arrow.down.circle")
                    .font(.system(size: 20))
                    .foregroundColor(isAutoScrolling ? .RooCode.primary : (NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary))
            }
            .buttonStyle(PlainButtonStyle())
            .help("Автопрокрутка")
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 12)
    }
    
    private var footer: some View {
        HStack {
            Text("\(filteredLogs.count) записей")
                .font(.RooCode.caption)
                .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary)
            
            Spacer()
            
            SecondaryButton(title: "Очистить") {
                Logger.shared.clearLogs()
            }
            
            Button(action: { exportContent = Logger.shared.exportLogs(); showingExportAlert = true }) {
                Text("Экспорт")
                    .font(.RooCode.bodyEmphasized)
                    .foregroundColor(.white)
                    .frame(width: 100, height: 36)
                    .background(Color.RooCode.primary)
                    .cornerRadius(6)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 16)
    }
    
    private func copyLogs() {
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(exportContent, forType: .string)
    }
    
    private func saveLogs() {
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.text]
        savePanel.nameFieldStringValue = "ultrahink_logs.txt"
        
        savePanel.begin { response in
            if response == .OK, let url = savePanel.url {
                try? exportContent.write(to: url, atomically: true, encoding: .utf8)
            }
        }
    }
}

struct LogRow: View {
    let log: LogEntry
    
    var level: LogEntry.Level {
        LogEntry.Level(rawValue: log.level) ?? .info
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(formatTimestamp(log.timestamp))
                .font(.RooCode.codeSmall)
                .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.textSecondary : Color.RooCode.textSecondary)
                .frame(width: 100, alignment: .leading)
            
            Text(level.displayName)
                .font(.RooCode.codeSmall)
                .foregroundColor(Color(hex: level.color))
                .frame(width: 70, alignment: .leading)
            
            Text(log.message)
                .font(.RooCode.code)
                .foregroundColor(NSAppearance.current.isDark ? Color.RooCodeDark.text : Color.RooCode.text)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 4)
        .padding(.horizontal, 8)
        .background(level == .error ? Color.RooCode.error.opacity(0.05) : Color.clear)
        .cornerRadius(4)
    }
    
    private func formatTimestamp(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: date)
    }
}

#Preview {
    LogsView(isPresented: .constant(true))
        .environmentObject(LogManager.shared)
}